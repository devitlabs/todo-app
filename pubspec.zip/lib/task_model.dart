import 'package:isar/isar.dart';

part 'task_model.g.dart';

@collection
class Task {
  Id id = DateTime.now().millisecondsSinceEpoch;
  late String title;
  late String description;
  bool isCompleted = false;
  bool isArchived = false;

  Task({
    required this.id,
    required this.title,
    required this.description,
    this.isCompleted = false,
    this.isArchived = false,
  });
}

