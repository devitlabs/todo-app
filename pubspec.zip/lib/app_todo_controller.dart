import 'package:get/get.dart';
import 'package:todo_app/task_model.dart';
import 'package:uuid/uuid.dart';

class TaskController extends GetxController {
  var tasks = <TaskTable>[].obs;

  void addTask(String title, String description) {
    var uuid = Uuid();
    tasks.add(TaskTable(id: uuid.v1(),title: title, description: description));
  }


  void setIsComplete(String id,bool idComplete) {
    var taskIndex = tasks.indexWhere((task) => task.id == id);
    if (taskIndex != -1) {
      final kTask = tasks[taskIndex];
      kTask.isCompleted = idComplete;
      tasks[taskIndex] = kTask;
    }
  }

  List<TaskTable> getAllTask() {
    return tasks.where((task) => !task.isArchived).toList();
  }

  void deleteTask(String id) {
    var taskIndex = tasks.indexWhere((task) => task.id == id);
    if (taskIndex != -1) {
      final kTask = tasks[taskIndex];
      kTask.isArchived = true;
      tasks[taskIndex] = kTask;
    }
  }

  TaskTable? findTask(String? id) {
    if (id == null ) {
      return null;
    }
    final task = tasks.firstWhere((task) => task.id == id);
    if (task == -1 ) {
      return null;
    }
    return task;
  }

  void updateTask(String id, String title, String description) {
    var taskIndex = tasks.indexWhere((task) => task.id == id);
    if (taskIndex != -1) {
      final kTask = tasks[taskIndex];
      kTask.title = title;
      kTask.description = description;
      tasks[taskIndex] = kTask;
    }
  }
}
